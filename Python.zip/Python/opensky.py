#setup
from opensky_api import OpenSkyApi  #flight tracker api
import csv                          #used for file management 
#import tkinter as tk               #used for gui stuff if needed
import random                       #used to pick a random flight from readme.csv
import pandas as pd                #better file interaction 
from datetime import datetime       #unix timestamp convertions
import pytz                         #timezone converter
from re import search 

#variable declarations
info=[0,0]
data=[0,0,0,0,0]
deltaT = [0,0]
timeZ = [0,0,0,0]
airline = 0

#Function definitions
def fileManage():                           #clears the flight storing data file and then adds the header line
    with open("readme.csv", 'w') as f:      #open, clear, and close readme.csv
        f.truncate
        f.close

    header = ['hexcall', 'callsign', 'country', 'time', 'last contact', 'longitude', 'latitude', 'b.altitude', 'ground', 'velocity', 'direction', 'vertical rate', 'geo.altitude', 'squawk', 'position source' ]
    #above is the creation of a header for readme.csv

    with open("readme.csv", 'w') as f:                                  #open, store header , write header to file, and close readme.csv
        hold = csv.DictWriter(f, delimiter =',', fieldnames = header)
        hold.writeheader()
        f.close

def getLoc():                           #used to get all flights from a set ranges lat and long locations as well as the direction they are traveling
    name = open('readme.csv', 'r')      #open readme.csv
    file = csv.DictReader(name)         #read from file with mapping based on header column titles

    #variable declartion
    longitude = []
    latitude = []
    direction = []

    for col in file:                            #for each column in readme.csv
        longitude.append(col['longitude'])      #get data from longitude column and save it to longitude array/list
        latitude.append(col['latitude'])        #get data from latitude column and save it to latitude array/list
        direction.append(col['direction'])      #get data from direction column and save it to direction array/list

        #print('long:', longitude)
        #print('\n')
        #print('lat:', latitude)
        #print('\n')
        #print('heading:', direction)
    
    name.close                          #close the file

def getRandFlight(info, data, deltaT):          #pick a random flight within the boundaries; basic simulation of if a flight was selected on the website without the interaction being built atm
    with open("readme.csv") as file:        #open the file and read from it
        reader = csv.reader(file)
        row = random.choice(list(reader))   #pick a random row in the file and save it to row array/list

        #print(row)
        file.close                          #close the file

    header = ['hexcall', 'callsign', 'country', 'time', 'last contact', 'longitude', 'latitude', 'b.altitude', 'ground', 'velocity', 'direction', 'vertical rate', 'geo.altitude', 'squawk', 'position source' ]
    #above creates a header for our new file

    with open('test.csv', 'w', newline='') as file:                         #open new file 
        hold = csv.DictWriter(file, delimiter =',', fieldnames = header)    #write to file using specific mapping
        hold.writeheader()                                                  #write header to the file

        writer = csv.writer(file)                                           #write to file
        writer.writerow(row)                                                #write data stored in row array/list to file
        file.close                                                          #close the file

    a = row[1]      #callsign
    b = row[2]      #country
    c = row[0]      #icao
    d = row[5]      #longitude
    e = row[6]      #latitude
    f = row[13]     #sqwuak
    g = row[14]     #position source
    h = row[3]      #time
    i = row[4]      #last contact


    info = [a, b]           #for callsign and country; for first dropdown like window in flightradar24
    #print(info)
    data = [c, d, e, f,g]   #for icao, long, lat, squawk, and position source like data source dropdown in flightradar24 
    #print(data)
    deltaT = [h,i]          #for time and last position update and time at last general update
    #print(deltaT)

    return info, data, deltaT

def getTime(deltaT, timeZ):                    #calculate time in UTC and EST between last position update and general update of the randomly selected flight
    #varibale declation
    gen = deltaT[1]
    last = deltaT[0]
    newGen = int(gen)
    newLast = int(last)

    local_gen = datetime.fromtimestamp(newGen)       #get date and time from gen update
    local_last = datetime.fromtimestamp(newLast)     #get date and time from last update

    utc_gen = local_gen.astimezone(pytz.UTC)         #change date and time from gen update to utc
    utc_last = local_last.astimezone(pytz.UTC)       #change date and time from last update to utc
    
    #print("EST gen time and EST last time:")
    #print(local_gen, local_last)
    #print("EST gen time and EST last time:")
    #print(utc_gen, utc_last)

    timeZ = [local_gen, local_last, utc_gen, utc_last]      #save all time zones date and time convertions for gen update and last update to timeZ array/list
    return timeZ

def getAirline(info, airline):
    name = []
    name = info[0]
    count = 0

    a = name[0]
    b = name[1]
    c = name[2]

    id = []
    id = [a,b,c]
    string=''.join(id)
    #print(string)
    
    df = pd.read_csv('airline.csv')
    #print(df)
    for ind in df.index:
        if search(string, df['id'][ind]):
            #print(df['id'][ind], ind)
            x = ind
            
            with open('airline.csv', 'r') as f:
                hold = f.readlines()[x+1]
                #print(type(hold))
                #print(hold)
                res = hold.split(',')
                for i in res:
                    #print(i)

                    count = count + 1

                    if count == 2: 
                        airline = i
                        #print('the airline is:')
                        #print(airline)
    return airline


#main
    #sets range for the jacksonville section chart
lat_min = -85.0
lat_max = -80.0
lon_min = 28.0
lon_max = 33.0

#REST API Query
    #sets opensky username and password just in case it is needed
user_name = 'McFaddeK'
password = 'ERAU1926Eagle'

#main
api = OpenSkyApi(username=user_name, password=password)                 #provide username and password to api
states = api.get_states(bbox=(lon_min, lon_max, lat_min, lat_max))      #set range for the api to get data from

#varibale declarition
count = 0
i = 0

fileManage()

for s in states.states:                 #for all data in set range get all flight data

    count +=1
    
    #variable declaration
    icao = s.icao24
    call = s.callsign
    country = s.origin_country
    time = s.time_position
    contact = s.last_contact
    long = s.longitude
    lat = s.latitude
    baro = s.baro_altitude
    gnd = s.on_ground
    v = s.velocity
    track = s.true_track
    vRate = s.vertical_rate
    geo = s.geo_altitude
    squawk = s.squawk
    src = s.position_source

    #print(count, icao, call, country, time, contact, long, lat, baro, gnd, v, track, vRate, geo, squawk, src)
    data = [icao, call, country, time, contact, long, lat, baro, gnd, v, track, vRate, geo, squawk, src]        #save all flight data to array


    with open('readme.csv', 'a', newline='') as f:      #populate file with information from the data array and auto move to the next line then close the file
        writer = csv.writer(f)
        writer.writerow(data)
        f.close()

getLoc()
info, data, deltaT = getRandFlight(info, data, deltaT)
timeZ = getTime(deltaT, timeZ)
airline = getAirline(info, airline)










    





    
        


    



        










