# swagger_client.USVFRWallPlanningChartApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_product_edition**](USVFRWallPlanningChartApi.md#get_product_edition) | **GET** /vfr/wallplanning/info | Get WallPlan edition date and edition number by edition type and format
[**get_product_release**](USVFRWallPlanningChartApi.md#get_product_release) | **GET** /vfr/wallplanning/chart | Get WallPlan Chart release information with download link by edition and format


# **get_product_edition**
> get_product_edition(edition=edition, format=format)

Get WallPlan edition date and edition number by edition type and format



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.USVFRWallPlanningChartApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition information is returned. (optional) (default to current)
format = 'pdf' # str | Format of the requested chart. TIFF format contains georeferenced charts in a zip archive file and PDF is non-georeferenced charts. If omitted, the default PDF format is used. (optional) (default to pdf)

try:
    # Get WallPlan edition date and edition number by edition type and format
    api_instance.get_product_edition(edition=edition, format=format)
except ApiException as e:
    print("Exception when calling USVFRWallPlanningChartApi->get_product_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition information is returned. | [optional] [default to current]
 **format** | **str**| Format of the requested chart. TIFF format contains georeferenced charts in a zip archive file and PDF is non-georeferenced charts. If omitted, the default PDF format is used. | [optional] [default to pdf]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_product_release**
> get_product_release(edition=edition, format=format)

Get WallPlan Chart release information with download link by edition and format



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.USVFRWallPlanningChartApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)
format = 'pdf' # str | Format of the requested chart. TIFF format contains georeferenced charts contained within a zip archive and PDF is non-georeferenced charts. If omitted, the default PDF format is returned. (optional) (default to pdf)

try:
    # Get WallPlan Chart release information with download link by edition and format
    api_instance.get_product_release(edition=edition, format=format)
except ApiException as e:
    print("Exception when calling USVFRWallPlanningChartApi->get_product_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]
 **format** | **str**| Format of the requested chart. TIFF format contains georeferenced charts contained within a zip archive and PDF is non-georeferenced charts. If omitted, the default PDF format is returned. | [optional] [default to pdf]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

