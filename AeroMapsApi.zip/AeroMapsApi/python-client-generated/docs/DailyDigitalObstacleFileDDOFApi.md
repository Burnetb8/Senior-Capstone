# swagger_client.DailyDigitalObstacleFileDDOFApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_ddof_edition**](DailyDigitalObstacleFileDDOFApi.md#get_ddof_edition) | **GET** /ddof/info | Get Daily Digital Obstacle File edition information.
[**get_ddof_release**](DailyDigitalObstacleFileDDOFApi.md#get_ddof_release) | **GET** /ddof/chart | Get Daily Digital Obstacle File download link.


# **get_ddof_edition**
> get_ddof_edition()

Get Daily Digital Obstacle File edition information.

The Daily Digital Obstacle File is released by the FAA on a daily basis.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DailyDigitalObstacleFileDDOFApi()

try:
    # Get Daily Digital Obstacle File edition information.
    api_instance.get_ddof_edition()
except ApiException as e:
    print("Exception when calling DailyDigitalObstacleFileDDOFApi->get_ddof_edition: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_ddof_release**
> get_ddof_release()

Get Daily Digital Obstacle File download link.

The Daily Digital Obstacle File release is distributed as a zip file containing the latest obstacle information from the FAA database.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DailyDigitalObstacleFileDDOFApi()

try:
    # Get Daily Digital Obstacle File download link.
    api_instance.get_ddof_release()
except ApiException as e:
    print("Exception when calling DailyDigitalObstacleFileDDOFApi->get_ddof_release: %s\n" % e)
```

### Parameters
This endpoint does not need any parameter.

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

