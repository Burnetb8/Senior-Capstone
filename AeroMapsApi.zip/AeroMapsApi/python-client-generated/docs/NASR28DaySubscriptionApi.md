# swagger_client.NASR28DaySubscriptionApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_nasr_edition**](NASR28DaySubscriptionApi.md#get_nasr_edition) | **GET** /nfdc/nasr/info | Get the National Flight Data Center NASR 28 day subscription file edition information
[**get_nasr_subscription**](NASR28DaySubscriptionApi.md#get_nasr_subscription) | **GET** /nfdc/nasr/chart | Get the National Flight Data Center NASR 28 day subscription file


# **get_nasr_edition**
> get_nasr_edition(edition=edition)

Get the National Flight Data Center NASR 28 day subscription file edition information



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.NASR28DaySubscriptionApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)

try:
    # Get the National Flight Data Center NASR 28 day subscription file edition information
    api_instance.get_nasr_edition(edition=edition)
except ApiException as e:
    print("Exception when calling NASR28DaySubscriptionApi->get_nasr_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_nasr_subscription**
> get_nasr_subscription(edition=edition)

Get the National Flight Data Center NASR 28 day subscription file



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.NASR28DaySubscriptionApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)

try:
    # Get the National Flight Data Center NASR 28 day subscription file
    api_instance.get_nasr_subscription(edition=edition)
except ApiException as e:
    print("Exception when calling NASR28DaySubscriptionApi->get_nasr_subscription: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

