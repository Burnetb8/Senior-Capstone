# swagger_client.DigitalEnrouteSupplementDERSApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_ders_edition**](DigitalEnrouteSupplementDERSApi.md#get_ders_edition) | **GET** /ders/info | Get Digital Enroute Supplement edition information.
[**get_ders_release**](DigitalEnrouteSupplementDERSApi.md#get_ders_release) | **GET** /ders/chart | Get Digital Enroute Supplement download link.


# **get_ders_edition**
> get_ders_edition(edition=edition)

Get Digital Enroute Supplement edition information.

The Digital Enroute Supplement release has been deprecated and is no longer published by the FAA.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DigitalEnrouteSupplementDERSApi()
edition = 'current' # str | Requested product edition. If omitted, current edition is returned. (optional) (default to current)

try:
    # Get Digital Enroute Supplement edition information.
    api_instance.get_ders_edition(edition=edition)
except ApiException as e:
    print("Exception when calling DigitalEnrouteSupplementDERSApi->get_ders_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, current edition is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_ders_release**
> get_ders_release(edition=edition)

Get Digital Enroute Supplement download link.

The Digital Enroute Supplement release has been deprecated and is no longer published by the FAA..

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DigitalEnrouteSupplementDERSApi()
edition = 'current' # str | Requested product edition. If omitted, current edition is returned. (optional) (default to current)

try:
    # Get Digital Enroute Supplement download link.
    api_instance.get_ders_release(edition=edition)
except ApiException as e:
    print("Exception when calling DigitalEnrouteSupplementDERSApi->get_ders_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, current edition is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

