# swagger_client.GulfOfMexicoIFREnrouteChartApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_gom_edition**](GulfOfMexicoIFREnrouteChartApi.md#get_gom_edition) | **GET** /enroute/gom/info | Get Gulf of Mexico IFR enroute chart edition date and edition number
[**get_gom_release**](GulfOfMexicoIFREnrouteChartApi.md#get_gom_release) | **GET** /enroute/gom/chart | Get Gulf of Mexico IFR enroute chart edition date, edition number, and product download URL


# **get_gom_edition**
> get_gom_edition(edition=edition, geoname=geoname)

Get Gulf of Mexico IFR enroute chart edition date and edition number

If a geographic area is not supplied, both central and west product edition information is returned.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.GulfOfMexicoIFREnrouteChartApi()
edition = 'current' # str | Requested product edition. If omitted, current edition is returned. (optional) (default to current)
geoname = 'geoname_example' # str | Requested Gulf of Mexico geographic area. If omitted, both west and central are returned. (optional)

try:
    # Get Gulf of Mexico IFR enroute chart edition date and edition number
    api_instance.get_gom_edition(edition=edition, geoname=geoname)
except ApiException as e:
    print("Exception when calling GulfOfMexicoIFREnrouteChartApi->get_gom_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, current edition is returned. | [optional] [default to current]
 **geoname** | **str**| Requested Gulf of Mexico geographic area. If omitted, both west and central are returned. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_gom_release**
> get_gom_release(edition=edition, format=format, geoname=geoname)

Get Gulf of Mexico IFR enroute chart edition date, edition number, and product download URL

The Gulf of Mexico IFR enroute chart is distributed as a zip file that contains multiple PDF charts.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.GulfOfMexicoIFREnrouteChartApi()
edition = 'current' # str | Requested product edition. If omitted, current edition is returned. (optional) (default to current)
format = 'pdf' # str | Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned. (optional) (default to pdf)
geoname = 'geoname_example' # str | Requested Gulf of Mexico geographic area. If omitted, both west and central links are returned. (optional)

try:
    # Get Gulf of Mexico IFR enroute chart edition date, edition number, and product download URL
    api_instance.get_gom_release(edition=edition, format=format, geoname=geoname)
except ApiException as e:
    print("Exception when calling GulfOfMexicoIFREnrouteChartApi->get_gom_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, current edition is returned. | [optional] [default to current]
 **format** | **str**| Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned. | [optional] [default to pdf]
 **geoname** | **str**| Requested Gulf of Mexico geographic area. If omitted, both west and central links are returned. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

