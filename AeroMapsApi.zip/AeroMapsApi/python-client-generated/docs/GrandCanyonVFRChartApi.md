# swagger_client.GrandCanyonVFRChartApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_grand_canyon_edition**](GrandCanyonVFRChartApi.md#get_grand_canyon_edition) | **GET** /vfr/grandcanyon/info | Get VFR edition date and edition number by edition type of current or next
[**get_grand_canyon_release**](GrandCanyonVFRChartApi.md#get_grand_canyon_release) | **GET** /vfr/grandcanyon/chart | Get VFR Grand Canyon chart edition information and download link


# **get_grand_canyon_edition**
> get_grand_canyon_edition(edition=edition)

Get VFR edition date and edition number by edition type of current or next



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.GrandCanyonVFRChartApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition information is returned. (optional) (default to current)

try:
    # Get VFR edition date and edition number by edition type of current or next
    api_instance.get_grand_canyon_edition(edition=edition)
except ApiException as e:
    print("Exception when calling GrandCanyonVFRChartApi->get_grand_canyon_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition information is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_grand_canyon_release**
> get_grand_canyon_release(edition=edition)

Get VFR Grand Canyon chart edition information and download link



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.GrandCanyonVFRChartApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)

try:
    # Get VFR Grand Canyon chart edition information and download link
    api_instance.get_grand_canyon_release(edition=edition)
except ApiException as e:
    print("Exception when calling GrandCanyonVFRChartApi->get_grand_canyon_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

