# swagger_client.DigitalEnrouteChartsUSDDECUSApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_dec_edition**](DigitalEnrouteChartsUSDDECUSApi.md#get_dec_edition) | **GET** /dec/info | Get CIFP edition date and edition number by edition type of current or next. If the edition is left blank or null, the default edition of current is used.
[**get_dec_release**](DigitalEnrouteChartsUSDDECUSApi.md#get_dec_release) | **GET** /dec/chart | Get Digital Enroute Chart download link by edition type of current or next. If edition is left blank or null, the default edition of current is used.


# **get_dec_edition**
> get_dec_edition(edition=edition)

Get CIFP edition date and edition number by edition type of current or next. If the edition is left blank or null, the default edition of current is used.



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DigitalEnrouteChartsUSDDECUSApi()
edition = 'current' # str | Requested product edition. If omitted, current edition is returned. (optional) (default to current)

try:
    # Get CIFP edition date and edition number by edition type of current or next. If the edition is left blank or null, the default edition of current is used.
    api_instance.get_dec_edition(edition=edition)
except ApiException as e:
    print("Exception when calling DigitalEnrouteChartsUSDDECUSApi->get_dec_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, current edition is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_dec_release**
> get_dec_release(edition=edition)

Get Digital Enroute Chart download link by edition type of current or next. If edition is left blank or null, the default edition of current is used.

The DEC US release is distributed as a zip file containing charts.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DigitalEnrouteChartsUSDDECUSApi()
edition = 'current' # str | Requested product edition. If omitted, current edition is returned. (optional) (default to current)

try:
    # Get Digital Enroute Chart download link by edition type of current or next. If edition is left blank or null, the default edition of current is used.
    api_instance.get_dec_release(edition=edition)
except ApiException as e:
    print("Exception when calling DigitalEnrouteChartsUSDDECUSApi->get_dec_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, current edition is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

