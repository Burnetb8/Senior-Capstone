# swagger_client.TerminalAreaChartsApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_tac_edition**](TerminalAreaChartsApi.md#get_tac_edition) | **GET** /vfr/tac/info | Get Terminal Area Chart edition date and edition number by edition type and geoname
[**get_tac_release**](TerminalAreaChartsApi.md#get_tac_release) | **GET** /vfr/tac/chart | Get Terminal Area Chart download link by edition, format, and geoname


# **get_tac_edition**
> get_tac_edition(geoname, edition=edition)

Get Terminal Area Chart edition date and edition number by edition type and geoname

Geoname is a city for which the chart is requested. Valid cities can be found on the FAA public web site at FAA Home > Air Traffic > Flight Information > Aeronautical Information Services > Digital Products > VFR Charts > Terminal Area Chart tab

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.TerminalAreaChartsApi()
geoname = 'geoname_example' # str | A US city for which the chart is requested.
edition = 'current' # str | Requested product edition. If omitted, the default current edition information is returned. (optional) (default to current)

try:
    # Get Terminal Area Chart edition date and edition number by edition type and geoname
    api_instance.get_tac_edition(geoname, edition=edition)
except ApiException as e:
    print("Exception when calling TerminalAreaChartsApi->get_tac_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **geoname** | **str**| A US city for which the chart is requested. | 
 **edition** | **str**| Requested product edition. If omitted, the default current edition information is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_tac_release**
> get_tac_release(geoname, edition=edition, format=format)

Get Terminal Area Chart download link by edition, format, and geoname

TIFF formatted files are geo-referenced while PDF format is not geo-referenced. Geoname is a city for which the chart is requested. Valid cities can be found on the FAA public web site at FAA Home > Air Traffic > Flight Information > Aeronautical Information Services > Digital Products > VFR Charts > Terminal Area Chart tab

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.TerminalAreaChartsApi()
geoname = 'geoname_example' # str | A US city for which the chart is requested.
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)
format = 'pdf' # str | Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned. (optional) (default to pdf)

try:
    # Get Terminal Area Chart download link by edition, format, and geoname
    api_instance.get_tac_release(geoname, edition=edition, format=format)
except ApiException as e:
    print("Exception when calling TerminalAreaChartsApi->get_tac_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **geoname** | **str**| A US city for which the chart is requested. | 
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]
 **format** | **str**| Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned. | [optional] [default to pdf]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

