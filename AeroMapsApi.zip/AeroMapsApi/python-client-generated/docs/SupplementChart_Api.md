# swagger_client.SupplementChart_Api

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_supplement_edition**](SupplementChart_Api.md#get_supplement_edition) | **GET** /supplement/info | Get Supplement chart edition information by requesting an edition and volume.
[**get_supplement_release**](SupplementChart_Api.md#get_supplement_release) | **GET** /supplement/chart | Get Supplement chart download information by requesting an edition with a valid US volume.


# **get_supplement_edition**
> get_supplement_edition(edition=edition, volume=volume)

Get Supplement chart edition information by requesting an edition and volume.



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SupplementChart_Api()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)
volume = 'volume_example' # str | Requested volume of Supplement chart set. If omitted, the edition information for the complete US set is returned. (optional)

try:
    # Get Supplement chart edition information by requesting an edition and volume.
    api_instance.get_supplement_edition(edition=edition, volume=volume)
except ApiException as e:
    print("Exception when calling SupplementChart_Api->get_supplement_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]
 **volume** | **str**| Requested volume of Supplement chart set. If omitted, the edition information for the complete US set is returned. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_supplement_release**
> get_supplement_release(edition=edition, volume=volume)

Get Supplement chart download information by requesting an edition with a valid US volume.

The Supplement chart is distributed in two formats - zip and pdf. The US complete set is returned as a ZIP file while all other volumes consist of individual PDF files.Requests for charts by volume other than US complete set returns a list of download URLs which can be quite extensive.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.SupplementChart_Api()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)
volume = 'volume_example' # str | Requested volume of Supplement chart set. If omitted, the complete US set is returned. (optional)

try:
    # Get Supplement chart download information by requesting an edition with a valid US volume.
    api_instance.get_supplement_release(edition=edition, volume=volume)
except ApiException as e:
    print("Exception when calling SupplementChart_Api->get_supplement_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]
 **volume** | **str**| Requested volume of Supplement chart set. If omitted, the complete US set is returned. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

