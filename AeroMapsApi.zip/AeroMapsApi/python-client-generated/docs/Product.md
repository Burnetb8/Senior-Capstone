# Product

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**product_name** | **str** |  | [optional] 
**change** | **str** |  | [optional] 
**chart_name** | **str** |  | [optional] 
**icao** | **str** |  | [optional] 
**airport_id** | **str** |  | [optional] 
**airport_name** | **str** |  | [optional] 
**city_name** | **str** |  | [optional] 
**url** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


