# swagger_client.VFRHelicopterRouteChartApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_gulf_coast_edition**](VFRHelicopterRouteChartApi.md#get_gulf_coast_edition) | **GET** /vfr/helicopter/gulf/info | Get VFR GulfCoast Route Chart edition date and edition number by edition type of &#39;current&#39; or &#39;next&#39; 
[**get_gulf_coast_release**](VFRHelicopterRouteChartApi.md#get_gulf_coast_release) | **GET** /vfr/helicopter/gulf/chart | Get GulfCoast Route Chart download link by edition
[**get_helicopter_edition**](VFRHelicopterRouteChartApi.md#get_helicopter_edition) | **GET** /vfr/helicopter/info | Get VFR Helicopter Route Chart edition date and edition number by edition type of current or next and geoname
[**get_helicopter_release**](VFRHelicopterRouteChartApi.md#get_helicopter_release) | **GET** /vfr/helicopter/chart | Get VFR Helicopter Route Chart download link by edition and geoname


# **get_gulf_coast_edition**
> get_gulf_coast_edition(edition=edition)

Get VFR GulfCoast Route Chart edition date and edition number by edition type of 'current' or 'next' 



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.VFRHelicopterRouteChartApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)

try:
    # Get VFR GulfCoast Route Chart edition date and edition number by edition type of 'current' or 'next' 
    api_instance.get_gulf_coast_edition(edition=edition)
except ApiException as e:
    print("Exception when calling VFRHelicopterRouteChartApi->get_gulf_coast_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_gulf_coast_release**
> get_gulf_coast_release(edition=edition, format=format)

Get GulfCoast Route Chart download link by edition

The geoname is absent from this operation and defaults to U.S Gulf Coast

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.VFRHelicopterRouteChartApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)
format = 'pdf' # str | Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned. (optional) (default to pdf)

try:
    # Get GulfCoast Route Chart download link by edition
    api_instance.get_gulf_coast_release(edition=edition, format=format)
except ApiException as e:
    print("Exception when calling VFRHelicopterRouteChartApi->get_gulf_coast_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]
 **format** | **str**| Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned. | [optional] [default to pdf]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_helicopter_edition**
> get_helicopter_edition(edition=edition, geoname=geoname)

Get VFR Helicopter Route Chart edition date and edition number by edition type of current or next and geoname



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.VFRHelicopterRouteChartApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)
geoname = 'geoname_example' # str | Geoname which is a city for which the chart is requested. If omitted, charts for all cities are returned. (optional)

try:
    # Get VFR Helicopter Route Chart edition date and edition number by edition type of current or next and geoname
    api_instance.get_helicopter_edition(edition=edition, geoname=geoname)
except ApiException as e:
    print("Exception when calling VFRHelicopterRouteChartApi->get_helicopter_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]
 **geoname** | **str**| Geoname which is a city for which the chart is requested. If omitted, charts for all cities are returned. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_helicopter_release**
> get_helicopter_release(edition=edition, format=format, geoname=geoname)

Get VFR Helicopter Route Chart download link by edition and geoname

Geoname is a city for which the chart is requested. Valid cities can be found on the FAA public web site under FAA Home > Air Traffic > Flight Information > Aeronautical Information Services > Digital Products > VFR Charts > Helicopter tab

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.VFRHelicopterRouteChartApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)
format = 'pdf' # str | Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned. (optional) (default to pdf)
geoname = 'geoname_example' # str | Geoname which is a city for which the chart is requested. If omitted, charts for all cities are returned. (optional)

try:
    # Get VFR Helicopter Route Chart download link by edition and geoname
    api_instance.get_helicopter_release(edition=edition, format=format, geoname=geoname)
except ApiException as e:
    print("Exception when calling VFRHelicopterRouteChartApi->get_helicopter_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]
 **format** | **str**| Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned. | [optional] [default to pdf]
 **geoname** | **str**| Geoname which is a city for which the chart is requested. If omitted, charts for all cities are returned. | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

