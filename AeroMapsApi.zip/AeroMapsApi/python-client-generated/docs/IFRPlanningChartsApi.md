# swagger_client.IFRPlanningChartsApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_ifr_planning_chart**](IFRPlanningChartsApi.md#get_ifr_planning_chart) | **GET** /ifr/planning/chart | Get IFR planning download link by edition and format
[**get_ifr_planning_info**](IFRPlanningChartsApi.md#get_ifr_planning_info) | **GET** /ifr/planning/info | Get Planning Chart edition date and edition number by edition type


# **get_ifr_planning_chart**
> get_ifr_planning_chart(edition=edition, format=format)

Get IFR planning download link by edition and format

TIFF formatted files are geo-referenced while PDF format is not geo-referenced.  The specific chart returned by this operation is the IFR PLANNING chart found on the FAA public web site at FAA Home > Air Traffic > Flight Information > Aeronautical Information Services > Digital Products > IFR Charts and DERS > Planning tab

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.IFRPlanningChartsApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)
format = 'pdf' # str | Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default PDF format is returned. (optional) (default to pdf)

try:
    # Get IFR planning download link by edition and format
    api_instance.get_ifr_planning_chart(edition=edition, format=format)
except ApiException as e:
    print("Exception when calling IFRPlanningChartsApi->get_ifr_planning_chart: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]
 **format** | **str**| Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default PDF format is returned. | [optional] [default to pdf]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_ifr_planning_info**
> get_ifr_planning_info(edition=edition)

Get Planning Chart edition date and edition number by edition type



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.IFRPlanningChartsApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition information is returned. (optional) (default to current)

try:
    # Get Planning Chart edition date and edition number by edition type
    api_instance.get_ifr_planning_info(edition=edition)
except ApiException as e:
    print("Exception when calling IFRPlanningChartsApi->get_ifr_planning_info: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition information is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

