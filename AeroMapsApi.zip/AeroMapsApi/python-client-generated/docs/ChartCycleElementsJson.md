# ChartCycleElementsJson

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chart_cycle_period_code** | **str** |  | [optional] 
**chart_cycle_type_code** | **str** |  | [optional] 
**chart_effective_date** | **datetime** |  | [optional] 
**chart_cycle_number** | **str** |  | [optional] 
**query_date** | **str** |  | [optional] 
**chart_city_name** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


