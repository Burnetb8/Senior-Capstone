# swagger_client.USTerminalProceduresPublicationTPPApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_tpp_edition**](USTerminalProceduresPublicationTPPApi.md#get_tpp_edition) | **GET** /dtpp/info | Get Terminal Procedure Publication chart edition information by requesting an edition with geographic area of United States or one of the 50 US states
[**get_tpp_release**](USTerminalProceduresPublicationTPPApi.md#get_tpp_release) | **GET** /dtpp/chart | Get Terminal Procedure Publication chart download information by requesting an edition with geographic area of United States or a valid US State Name.


# **get_tpp_edition**
> get_tpp_edition(edition=edition, geoname=geoname)

Get Terminal Procedure Publication chart edition information by requesting an edition with geographic area of United States or one of the 50 US states

The US Terminal Procedure Publication is released on a 28 day airspace cycle. Edition information is identical regardless of the geographic area or format of the desired charts.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.USTerminalProceduresPublicationTPPApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition information is returned. (optional) (default to current)
geoname = 'US' # str | Requested geographic region of Terminal Procedures Publication chart set. Specify US or a valid full US state name such as Alaska. If omitted, edition information for the complete US set is returned. (optional) (default to US)

try:
    # Get Terminal Procedure Publication chart edition information by requesting an edition with geographic area of United States or one of the 50 US states
    api_instance.get_tpp_edition(edition=edition, geoname=geoname)
except ApiException as e:
    print("Exception when calling USTerminalProceduresPublicationTPPApi->get_tpp_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition information is returned. | [optional] [default to current]
 **geoname** | **str**| Requested geographic region of Terminal Procedures Publication chart set. Specify US or a valid full US state name such as Alaska. If omitted, edition information for the complete US set is returned. | [optional] [default to US]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_tpp_release**
> get_tpp_release(edition=edition, geoname=geoname)

Get Terminal Procedure Publication chart download information by requesting an edition with geographic area of United States or a valid US State Name.

The complete United States Terminal Procedure Publication (TPP) release is distributed as a set of zip files containing charts and verification software. Requests for charts by state returns a list of download URLs which can be quite extensive.  All 50 US states are valid for requesting chart publication download URLs. The special 'changeset' edition operates against the current release and returns the charts that were changed since the previous release. 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.USTerminalProceduresPublicationTPPApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)
geoname = 'US' # str | Requested geographic region of Terminal Procedures Publication chart set. Specify either US or a valid full state name such as Alaska. If omitted, the default US complete set is returned. (optional) (default to US)

try:
    # Get Terminal Procedure Publication chart download information by requesting an edition with geographic area of United States or a valid US State Name.
    api_instance.get_tpp_release(edition=edition, geoname=geoname)
except ApiException as e:
    print("Exception when calling USTerminalProceduresPublicationTPPApi->get_tpp_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]
 **geoname** | **str**| Requested geographic region of Terminal Procedures Publication chart set. Specify either US or a valid full state name such as Alaska. If omitted, the default US complete set is returned. | [optional] [default to US]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

