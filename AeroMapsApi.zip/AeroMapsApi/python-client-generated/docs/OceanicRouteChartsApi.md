# swagger_client.OceanicRouteChartsApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_oceanic_route_chart**](OceanicRouteChartsApi.md#get_oceanic_route_chart) | **GET** /ifr/oceanic/chart | Get Oceanic Route Chart download link by edition, format, and geoname
[**get_oceanic_route_edition**](OceanicRouteChartsApi.md#get_oceanic_route_edition) | **GET** /ifr/oceanic/info | Get Oceanic Route Chart edition information by edition type


# **get_oceanic_route_chart**
> get_oceanic_route_chart(geoname, edition=edition, format=format)

Get Oceanic Route Chart download link by edition, format, and geoname

TIFF formatted files are geo-referenced while PDF format is not geo-referenced. Geoname is a geographic area for which the chart is requested. Valid geographic names are Pacific (PORC), North Atlantic (NARC), and Wester Atlantic (WATRS) 

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.OceanicRouteChartsApi()
geoname = 'PORC' # str | A geographic area for which the chart is requested (default to PORC)
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)
format = 'pdf' # str | Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned. (optional) (default to pdf)

try:
    # Get Oceanic Route Chart download link by edition, format, and geoname
    api_instance.get_oceanic_route_chart(geoname, edition=edition, format=format)
except ApiException as e:
    print("Exception when calling OceanicRouteChartsApi->get_oceanic_route_chart: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **geoname** | **str**| A geographic area for which the chart is requested | [default to PORC]
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]
 **format** | **str**| Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned. | [optional] [default to pdf]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_oceanic_route_edition**
> get_oceanic_route_edition(edition=edition)

Get Oceanic Route Chart edition information by edition type

All oceanic charts are released on a regular 56 day cycle. The format and geographic name are not necessary to obtain edition information.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.OceanicRouteChartsApi()
edition = 'current' # str | Requested product edition. If omitted, the default current edition information is returned. (optional) (default to current)

try:
    # Get Oceanic Route Chart edition information by edition type
    api_instance.get_oceanic_route_edition(edition=edition)
except ApiException as e:
    print("Exception when calling OceanicRouteChartsApi->get_oceanic_route_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, the default current edition information is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

