# swagger_client.IFREnrouteChartsApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_ifr_enroute_edition**](IFREnrouteChartsApi.md#get_ifr_enroute_edition) | **GET** /enroute/info | Get IFR Enroute Charts edition date and edition number by edition type of current or next
[**get_ifr_enroute_release**](IFREnrouteChartsApi.md#get_ifr_enroute_release) | **GET** /enroute/chart | Get IFR Enroute Charts download link by edition, format, geoname, and seriesType


# **get_ifr_enroute_edition**
> get_ifr_enroute_edition(edition=edition)

Get IFR Enroute Charts edition date and edition number by edition type of current or next



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.IFREnrouteChartsApi()
edition = 'current' # str | Requested product edition (optional) (default to current)

try:
    # Get IFR Enroute Charts edition date and edition number by edition type of current or next
    api_instance.get_ifr_enroute_edition(edition=edition)
except ApiException as e:
    print("Exception when calling IFREnrouteChartsApi->get_ifr_enroute_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_ifr_enroute_release**
> get_ifr_enroute_release(geoname, series_type, edition=edition, format=format)

Get IFR Enroute Charts download link by edition, format, geoname, and seriesType

TIFF formatted files are geo-referenced while PDF format is not geo-referenced. Geoname is either US, Alaska, Pacific, or Caribbean, depending on the desired chart. A list of available charts by format, geoname, and series type can be found on the FAA public web site at FAA Home > Air Traffic > Flight Information > Aeronautical Information Services  > Digital Products > IFR Charts and DERS > Low, High Areas tab.  The valid values for seriesType are Low, High, or Area.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.IFREnrouteChartsApi()
geoname = 'geoname_example' # str | Geographic region for requested chart
series_type = 'series_type_example' # str | The series type
edition = 'current' # str | Requested product edition. If omitted, the default current edition is returned. (optional) (default to current)
format = 'pdf' # str | Format of the requested chart. TIFF is georeferenced and PDF is not georeferencedIf omitted, the default format of PDF is returned. (optional) (default to pdf)

try:
    # Get IFR Enroute Charts download link by edition, format, geoname, and seriesType
    api_instance.get_ifr_enroute_release(geoname, series_type, edition=edition, format=format)
except ApiException as e:
    print("Exception when calling IFREnrouteChartsApi->get_ifr_enroute_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **geoname** | **str**| Geographic region for requested chart | 
 **series_type** | **str**| The series type | 
 **edition** | **str**| Requested product edition. If omitted, the default current edition is returned. | [optional] [default to current]
 **format** | **str**| Format of the requested chart. TIFF is georeferenced and PDF is not georeferencedIf omitted, the default format of PDF is returned. | [optional] [default to pdf]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

