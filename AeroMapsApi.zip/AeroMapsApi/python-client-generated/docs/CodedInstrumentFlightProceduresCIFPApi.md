# swagger_client.CodedInstrumentFlightProceduresCIFPApi

All URIs are relative to *https://soa.smext.faa.gov/apra*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_cifp_edition**](CodedInstrumentFlightProceduresCIFPApi.md#get_cifp_edition) | **GET** /cifp/info | Get CIFP edition date and edition number by edition type of current or next. If the edition is left blank or null, the default edition of current is used.
[**get_cifp_release**](CodedInstrumentFlightProceduresCIFPApi.md#get_cifp_release) | **GET** /cifp/chart | Get CIFP chart download link by edition type of current or next. If edition is left blank or null, the default edition of current is used.


# **get_cifp_edition**
> get_cifp_edition(edition=edition)

Get CIFP edition date and edition number by edition type of current or next. If the edition is left blank or null, the default edition of current is used.



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CodedInstrumentFlightProceduresCIFPApi()
edition = 'current' # str | Requested product edition. If omitted, current edition is returned. (optional) (default to current)

try:
    # Get CIFP edition date and edition number by edition type of current or next. If the edition is left blank or null, the default edition of current is used.
    api_instance.get_cifp_edition(edition=edition)
except ApiException as e:
    print("Exception when calling CodedInstrumentFlightProceduresCIFPApi->get_cifp_edition: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, current edition is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_cifp_release**
> get_cifp_release(edition=edition)

Get CIFP chart download link by edition type of current or next. If edition is left blank or null, the default edition of current is used.

The CIFP release is distributed as a zip file containing charts and verification software.

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.CodedInstrumentFlightProceduresCIFPApi()
edition = 'current' # str | Requested product edition. If omitted, current edition is returned. (optional) (default to current)

try:
    # Get CIFP chart download link by edition type of current or next. If edition is left blank or null, the default edition of current is used.
    api_instance.get_cifp_release(edition=edition)
except ApiException as e:
    print("Exception when calling CodedInstrumentFlightProceduresCIFPApi->get_cifp_release: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **edition** | **str**| Requested product edition. If omitted, current edition is returned. | [optional] [default to current]

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/xml, application/json, text/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

