# Edition

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**edition_date** | **str** |  | 
**edition_number** | **int** |  | [optional] 
**product** | [**Product**](Product.md) |  | [optional] 
**geoname** | **str** |  | [optional] 
**edition_name** | **str** |  | [optional] 
**format** | **str** |  | [optional] 
**altitude** | **str** |  | [optional] 
**volume** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


