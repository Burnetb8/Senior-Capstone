# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestUSVFRWallPlanningChartController(BaseTestCase):
    """USVFRWallPlanningChartController integration test stubs"""

    def test_get_product_edition(self):
        """Test case for get_product_edition

        Get WallPlan edition date and edition number by edition type and format
        """
        query_string = [('edition', 'current'),
                        ('format', 'pdf')]
        response = self.client.open(
            '/apra/vfr/wallplanning/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_product_release(self):
        """Test case for get_product_release

        Get WallPlan Chart release information with download link by edition and format
        """
        query_string = [('edition', 'current'),
                        ('format', 'pdf')]
        response = self.client.open(
            '/apra/vfr/wallplanning/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
