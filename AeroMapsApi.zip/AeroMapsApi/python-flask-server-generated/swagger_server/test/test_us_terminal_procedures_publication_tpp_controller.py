# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestUSTerminalProceduresPublicationTPPController(BaseTestCase):
    """USTerminalProceduresPublicationTPPController integration test stubs"""

    def test_get_tpp_edition(self):
        """Test case for get_tpp_edition

        Get Terminal Procedure Publication chart edition information by requesting an edition with geographic area of United States or one of the 50 US states
        """
        query_string = [('edition', 'current'),
                        ('geoname', 'US')]
        response = self.client.open(
            '/apra/dtpp/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_tpp_release(self):
        """Test case for get_tpp_release

        Get Terminal Procedure Publication chart download information by requesting an edition with geographic area of United States or a valid US State Name.
        """
        query_string = [('edition', 'current'),
                        ('geoname', 'US')]
        response = self.client.open(
            '/apra/dtpp/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
