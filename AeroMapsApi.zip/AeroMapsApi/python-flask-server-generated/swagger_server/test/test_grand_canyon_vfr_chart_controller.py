# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestGrandCanyonVFRChartController(BaseTestCase):
    """GrandCanyonVFRChartController integration test stubs"""

    def test_get_grand_canyon_edition(self):
        """Test case for get_grand_canyon_edition

        Get VFR edition date and edition number by edition type of current or next
        """
        query_string = [('edition', 'current')]
        response = self.client.open(
            '/apra/vfr/grandcanyon/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_grand_canyon_release(self):
        """Test case for get_grand_canyon_release

        Get VFR Grand Canyon chart edition information and download link
        """
        query_string = [('edition', 'current')]
        response = self.client.open(
            '/apra/vfr/grandcanyon/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
