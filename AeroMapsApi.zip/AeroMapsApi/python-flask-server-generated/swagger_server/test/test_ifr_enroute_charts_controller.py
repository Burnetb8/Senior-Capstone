# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestIFREnrouteChartsController(BaseTestCase):
    """IFREnrouteChartsController integration test stubs"""

    def test_get_ifr_enroute_edition(self):
        """Test case for get_ifr_enroute_edition

        Get IFR Enroute Charts edition date and edition number by edition type of current or next
        """
        query_string = [('edition', 'current')]
        response = self.client.open(
            '/apra/enroute/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_ifr_enroute_release(self):
        """Test case for get_ifr_enroute_release

        Get IFR Enroute Charts download link by edition, format, geoname, and seriesType
        """
        query_string = [('edition', 'current'),
                        ('format', 'pdf'),
                        ('geoname', 'geoname_example'),
                        ('seriesType', 'seriesType_example')]
        response = self.client.open(
            '/apra/enroute/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
