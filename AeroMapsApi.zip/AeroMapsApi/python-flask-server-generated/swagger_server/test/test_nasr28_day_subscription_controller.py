# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestNASR28DaySubscriptionController(BaseTestCase):
    """NASR28DaySubscriptionController integration test stubs"""

    def test_get_nasr_edition(self):
        """Test case for get_nasr_edition

        Get the National Flight Data Center NASR 28 day subscription file edition information
        """
        query_string = [('edition', 'current')]
        response = self.client.open(
            '/apra/nfdc/nasr/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_nasr_subscription(self):
        """Test case for get_nasr_subscription

        Get the National Flight Data Center NASR 28 day subscription file
        """
        query_string = [('edition', 'current')]
        response = self.client.open(
            '/apra/nfdc/nasr/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
