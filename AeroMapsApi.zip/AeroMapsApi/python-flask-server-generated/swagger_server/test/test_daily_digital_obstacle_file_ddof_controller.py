# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestDailyDigitalObstacleFileDDOFController(BaseTestCase):
    """DailyDigitalObstacleFileDDOFController integration test stubs"""

    def test_get_ddof_edition(self):
        """Test case for get_ddof_edition

        Get Daily Digital Obstacle File edition information.
        """
        response = self.client.open(
            '/apra/ddof/info',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_ddof_release(self):
        """Test case for get_ddof_release

        Get Daily Digital Obstacle File download link.
        """
        response = self.client.open(
            '/apra/ddof/chart',
            method='GET')
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
