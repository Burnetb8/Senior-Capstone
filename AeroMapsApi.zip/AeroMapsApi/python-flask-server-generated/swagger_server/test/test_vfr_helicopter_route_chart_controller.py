# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestVFRHelicopterRouteChartController(BaseTestCase):
    """VFRHelicopterRouteChartController integration test stubs"""

    def test_get_gulf_coast_edition(self):
        """Test case for get_gulf_coast_edition

        Get VFR GulfCoast Route Chart edition date and edition number by edition type of 'current' or 'next' 
        """
        query_string = [('edition', 'current')]
        response = self.client.open(
            '/apra/vfr/helicopter/gulf/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_gulf_coast_release(self):
        """Test case for get_gulf_coast_release

        Get GulfCoast Route Chart download link by edition
        """
        query_string = [('edition', 'current'),
                        ('format', 'pdf')]
        response = self.client.open(
            '/apra/vfr/helicopter/gulf/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_helicopter_edition(self):
        """Test case for get_helicopter_edition

        Get VFR Helicopter Route Chart edition date and edition number by edition type of current or next and geoname
        """
        query_string = [('edition', 'current'),
                        ('geoname', 'geoname_example')]
        response = self.client.open(
            '/apra/vfr/helicopter/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_helicopter_release(self):
        """Test case for get_helicopter_release

        Get VFR Helicopter Route Chart download link by edition and geoname
        """
        query_string = [('edition', 'current'),
                        ('format', 'pdf'),
                        ('geoname', 'geoname_example')]
        response = self.client.open(
            '/apra/vfr/helicopter/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
