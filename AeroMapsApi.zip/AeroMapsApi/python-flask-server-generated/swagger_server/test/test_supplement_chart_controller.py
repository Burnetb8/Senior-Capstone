# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestSupplementChart_Controller(BaseTestCase):
    """SupplementChart_Controller integration test stubs"""

    def test_get_supplement_edition(self):
        """Test case for get_supplement_edition

        Get Supplement chart edition information by requesting an edition and volume.
        """
        query_string = [('edition', 'current'),
                        ('volume', 'volume_example')]
        response = self.client.open(
            '/apra/supplement/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_supplement_release(self):
        """Test case for get_supplement_release

        Get Supplement chart download information by requesting an edition with a valid US volume.
        """
        query_string = [('edition', 'current'),
                        ('volume', 'volume_example')]
        response = self.client.open(
            '/apra/supplement/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
