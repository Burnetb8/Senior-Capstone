# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestSectionalChartsController(BaseTestCase):
    """SectionalChartsController integration test stubs"""

    def test_get_sectional_chart(self):
        """Test case for get_sectional_chart

        Get Sectional Chart download link by edition, format, and geoname
        """
        query_string = [('geoname', 'geoname_example'),
                        ('edition', 'current'),
                        ('format', 'pdf')]
        response = self.client.open(
            '/apra/vfr/sectional/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_sectional_info(self):
        """Test case for get_sectional_info

        Get Sectional Chart edition date and edition number by edition type and geoname
        """
        query_string = [('geoname', 'geoname_example'),
                        ('edition', 'current')]
        response = self.client.open(
            '/apra/vfr/sectional/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
