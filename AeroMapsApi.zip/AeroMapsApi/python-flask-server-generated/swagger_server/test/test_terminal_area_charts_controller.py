# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestTerminalAreaChartsController(BaseTestCase):
    """TerminalAreaChartsController integration test stubs"""

    def test_get_tac_edition(self):
        """Test case for get_tac_edition

        Get Terminal Area Chart edition date and edition number by edition type and geoname
        """
        query_string = [('edition', 'current'),
                        ('geoname', 'geoname_example')]
        response = self.client.open(
            '/apra/vfr/tac/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_tac_release(self):
        """Test case for get_tac_release

        Get Terminal Area Chart download link by edition, format, and geoname
        """
        query_string = [('edition', 'current'),
                        ('format', 'pdf'),
                        ('geoname', 'geoname_example')]
        response = self.client.open(
            '/apra/vfr/tac/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
