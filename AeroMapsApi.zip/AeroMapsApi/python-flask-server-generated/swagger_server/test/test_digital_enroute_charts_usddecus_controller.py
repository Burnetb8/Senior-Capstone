# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestDigitalEnrouteChartsUSDDECUSController(BaseTestCase):
    """DigitalEnrouteChartsUSDDECUSController integration test stubs"""

    def test_get_dec_edition(self):
        """Test case for get_dec_edition

        Get CIFP edition date and edition number by edition type of current or next. If the edition is left blank or null, the default edition of current is used.
        """
        query_string = [('edition', 'current')]
        response = self.client.open(
            '/apra/dec/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_dec_release(self):
        """Test case for get_dec_release

        Get Digital Enroute Chart download link by edition type of current or next. If edition is left blank or null, the default edition of current is used.
        """
        query_string = [('edition', 'current')]
        response = self.client.open(
            '/apra/dec/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
