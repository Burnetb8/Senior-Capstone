# coding: utf-8

from __future__ import absolute_import

from flask import json
from six import BytesIO

from swagger_server.test import BaseTestCase


class TestDigitalEnrouteSupplementDERSController(BaseTestCase):
    """DigitalEnrouteSupplementDERSController integration test stubs"""

    def test_get_ders_edition(self):
        """Test case for get_ders_edition

        Get Digital Enroute Supplement edition information.
        """
        query_string = [('edition', 'current')]
        response = self.client.open(
            '/apra/ders/info',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))

    def test_get_ders_release(self):
        """Test case for get_ders_release

        Get Digital Enroute Supplement download link.
        """
        query_string = [('edition', 'current')]
        response = self.client.open(
            '/apra/ders/chart',
            method='GET',
            query_string=query_string)
        self.assert200(response,
                       'Response body is : ' + response.data.decode('utf-8'))


if __name__ == '__main__':
    import unittest
    unittest.main()
