import connexion
import six

from swagger_server import util


def get_oceanic_route_chart(geoname, edition=None, format=None):  # noqa: E501
    """Get Oceanic Route Chart download link by edition, format, and geoname

    TIFF formatted files are geo-referenced while PDF format is not geo-referenced. Geoname is a geographic area for which the chart is requested. Valid geographic names are Pacific (PORC), North Atlantic (NARC), and Wester Atlantic (WATRS)  # noqa: E501

    :param geoname: A geographic area for which the chart is requested
    :type geoname: str
    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str
    :param format: Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned.
    :type format: str

    :rtype: None
    """
    return 'do some magic!'


def get_oceanic_route_edition(edition=None):  # noqa: E501
    """Get Oceanic Route Chart edition information by edition type

    All oceanic charts are released on a regular 56 day cycle. The format and geographic name are not necessary to obtain edition information. # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition information is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'
