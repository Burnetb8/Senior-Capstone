import connexion
import six

from swagger_server import util


def get_product_edition(edition=None, format=None):  # noqa: E501
    """Get WallPlan edition date and edition number by edition type and format

     # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition information is returned.
    :type edition: str
    :param format: Format of the requested chart. TIFF format contains georeferenced charts in a zip archive file and PDF is non-georeferenced charts. If omitted, the default PDF format is used.
    :type format: str

    :rtype: None
    """
    return 'do some magic!'


def get_product_release(edition=None, format=None):  # noqa: E501
    """Get WallPlan Chart release information with download link by edition and format

     # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str
    :param format: Format of the requested chart. TIFF format contains georeferenced charts contained within a zip archive and PDF is non-georeferenced charts. If omitted, the default PDF format is returned.
    :type format: str

    :rtype: None
    """
    return 'do some magic!'
