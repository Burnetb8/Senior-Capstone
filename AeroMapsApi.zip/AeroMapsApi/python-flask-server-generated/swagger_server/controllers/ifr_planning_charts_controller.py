import connexion
import six

from swagger_server import util


def get_ifr_planning_chart(edition=None, format=None):  # noqa: E501
    """Get IFR planning download link by edition and format

    TIFF formatted files are geo-referenced while PDF format is not geo-referenced.  The specific chart returned by this operation is the IFR PLANNING chart found on the FAA public web site at FAA Home &gt; Air Traffic &gt; Flight Information &gt; Aeronautical Information Services &gt; Digital Products &gt; IFR Charts and DERS &gt; Planning tab # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str
    :param format: Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default PDF format is returned.
    :type format: str

    :rtype: None
    """
    return 'do some magic!'


def get_ifr_planning_info(edition=None):  # noqa: E501
    """Get Planning Chart edition date and edition number by edition type

     # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition information is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'
