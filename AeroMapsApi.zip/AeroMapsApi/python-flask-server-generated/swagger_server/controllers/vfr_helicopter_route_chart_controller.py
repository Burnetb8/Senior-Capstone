import connexion
import six

from swagger_server import util


def get_gulf_coast_edition(edition=None):  # noqa: E501
    """Get VFR GulfCoast Route Chart edition date and edition number by edition type of &#39;current&#39; or &#39;next&#39; 

     # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'


def get_gulf_coast_release(edition=None, format=None):  # noqa: E501
    """Get GulfCoast Route Chart download link by edition

    The geoname is absent from this operation and defaults to U.S Gulf Coast # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str
    :param format: Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned.
    :type format: str

    :rtype: None
    """
    return 'do some magic!'


def get_helicopter_edition(edition=None, geoname=None):  # noqa: E501
    """Get VFR Helicopter Route Chart edition date and edition number by edition type of current or next and geoname

     # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str
    :param geoname: Geoname which is a city for which the chart is requested. If omitted, charts for all cities are returned.
    :type geoname: str

    :rtype: None
    """
    return 'do some magic!'


def get_helicopter_release(edition=None, format=None, geoname=None):  # noqa: E501
    """Get VFR Helicopter Route Chart download link by edition and geoname

    Geoname is a city for which the chart is requested. Valid cities can be found on the FAA public web site under FAA Home &gt; Air Traffic &gt; Flight Information &gt; Aeronautical Information Services &gt; Digital Products &gt; VFR Charts &gt; Helicopter tab # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str
    :param format: Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned.
    :type format: str
    :param geoname: Geoname which is a city for which the chart is requested. If omitted, charts for all cities are returned.
    :type geoname: str

    :rtype: None
    """
    return 'do some magic!'
