import connexion
import six

from swagger_server import util


def get_tpp_edition(edition=None, geoname=None):  # noqa: E501
    """Get Terminal Procedure Publication chart edition information by requesting an edition with geographic area of United States or one of the 50 US states

    The US Terminal Procedure Publication is released on a 28 day airspace cycle. Edition information is identical regardless of the geographic area or format of the desired charts. # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition information is returned.
    :type edition: str
    :param geoname: Requested geographic region of Terminal Procedures Publication chart set. Specify US or a valid full US state name such as Alaska. If omitted, edition information for the complete US set is returned.
    :type geoname: str

    :rtype: None
    """
    return 'do some magic!'


def get_tpp_release(edition=None, geoname=None):  # noqa: E501
    """Get Terminal Procedure Publication chart download information by requesting an edition with geographic area of United States or a valid US State Name.

    The complete United States Terminal Procedure Publication (TPP) release is distributed as a set of zip files containing charts and verification software. Requests for charts by state returns a list of download URLs which can be quite extensive.  All 50 US states are valid for requesting chart publication download URLs. The special &#39;changeset&#39; edition operates against the current release and returns the charts that were changed since the previous release.  # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str
    :param geoname: Requested geographic region of Terminal Procedures Publication chart set. Specify either US or a valid full state name such as Alaska. If omitted, the default US complete set is returned.
    :type geoname: str

    :rtype: None
    """
    return 'do some magic!'
