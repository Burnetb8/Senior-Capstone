import connexion
import six

from swagger_server import util


def get_supplement_edition(edition=None, volume=None):  # noqa: E501
    """Get Supplement chart edition information by requesting an edition and volume.

     # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str
    :param volume: Requested volume of Supplement chart set. If omitted, the edition information for the complete US set is returned.
    :type volume: str

    :rtype: None
    """
    return 'do some magic!'


def get_supplement_release(edition=None, volume=None):  # noqa: E501
    """Get Supplement chart download information by requesting an edition with a valid US volume.

    The Supplement chart is distributed in two formats - zip and pdf. The US complete set is returned as a ZIP file while all other volumes consist of individual PDF files.Requests for charts by volume other than US complete set returns a list of download URLs which can be quite extensive. # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str
    :param volume: Requested volume of Supplement chart set. If omitted, the complete US set is returned.
    :type volume: str

    :rtype: None
    """
    return 'do some magic!'
