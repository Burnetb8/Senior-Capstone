import connexion
import six

from swagger_server import util


def get_ders_edition(edition=None):  # noqa: E501
    """Get Digital Enroute Supplement edition information.

    The Digital Enroute Supplement release has been deprecated and is no longer published by the FAA. # noqa: E501

    :param edition: Requested product edition. If omitted, current edition is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'


def get_ders_release(edition=None):  # noqa: E501
    """Get Digital Enroute Supplement download link.

    The Digital Enroute Supplement release has been deprecated and is no longer published by the FAA.. # noqa: E501

    :param edition: Requested product edition. If omitted, current edition is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'
