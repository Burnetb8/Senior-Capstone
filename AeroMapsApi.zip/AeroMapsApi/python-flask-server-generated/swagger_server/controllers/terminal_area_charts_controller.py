import connexion
import six

from swagger_server import util


def get_tac_edition(geoname, edition=None):  # noqa: E501
    """Get Terminal Area Chart edition date and edition number by edition type and geoname

    Geoname is a city for which the chart is requested. Valid cities can be found on the FAA public web site at FAA Home &gt; Air Traffic &gt; Flight Information &gt; Aeronautical Information Services &gt; Digital Products &gt; VFR Charts &gt; Terminal Area Chart tab # noqa: E501

    :param geoname: A US city for which the chart is requested.
    :type geoname: str
    :param edition: Requested product edition. If omitted, the default current edition information is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'


def get_tac_release(geoname, edition=None, format=None):  # noqa: E501
    """Get Terminal Area Chart download link by edition, format, and geoname

    TIFF formatted files are geo-referenced while PDF format is not geo-referenced. Geoname is a city for which the chart is requested. Valid cities can be found on the FAA public web site at FAA Home &gt; Air Traffic &gt; Flight Information &gt; Aeronautical Information Services &gt; Digital Products &gt; VFR Charts &gt; Terminal Area Chart tab # noqa: E501

    :param geoname: A US city for which the chart is requested.
    :type geoname: str
    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str
    :param format: Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned.
    :type format: str

    :rtype: None
    """
    return 'do some magic!'
