import connexion
import six

from swagger_server import util


def get_dec_edition(edition=None):  # noqa: E501
    """Get CIFP edition date and edition number by edition type of current or next. If the edition is left blank or null, the default edition of current is used.

     # noqa: E501

    :param edition: Requested product edition. If omitted, current edition is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'


def get_dec_release(edition=None):  # noqa: E501
    """Get Digital Enroute Chart download link by edition type of current or next. If edition is left blank or null, the default edition of current is used.

    The DEC US release is distributed as a zip file containing charts. # noqa: E501

    :param edition: Requested product edition. If omitted, current edition is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'
