import connexion
import six

from swagger_server import util


def get_ifr_enroute_edition(edition=None):  # noqa: E501
    """Get IFR Enroute Charts edition date and edition number by edition type of current or next

     # noqa: E501

    :param edition: Requested product edition
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'


def get_ifr_enroute_release(geoname, seriesType, edition=None, format=None):  # noqa: E501
    """Get IFR Enroute Charts download link by edition, format, geoname, and seriesType

    TIFF formatted files are geo-referenced while PDF format is not geo-referenced. Geoname is either US, Alaska, Pacific, or Caribbean, depending on the desired chart. A list of available charts by format, geoname, and series type can be found on the FAA public web site at FAA Home &gt; Air Traffic &gt; Flight Information &gt; Aeronautical Information Services  &gt; Digital Products &gt; IFR Charts and DERS &gt; Low, High Areas tab.  The valid values for seriesType are Low, High, or Area. # noqa: E501

    :param geoname: Geographic region for requested chart
    :type geoname: str
    :param seriesType: The series type
    :type seriesType: str
    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str
    :param format: Format of the requested chart. TIFF is georeferenced and PDF is not georeferencedIf omitted, the default format of PDF is returned.
    :type format: str

    :rtype: None
    """
    return 'do some magic!'
