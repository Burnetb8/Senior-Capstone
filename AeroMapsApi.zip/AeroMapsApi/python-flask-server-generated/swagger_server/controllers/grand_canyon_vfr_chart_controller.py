import connexion
import six

from swagger_server import util


def get_grand_canyon_edition(edition=None):  # noqa: E501
    """Get VFR edition date and edition number by edition type of current or next

     # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition information is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'


def get_grand_canyon_release(edition=None):  # noqa: E501
    """Get VFR Grand Canyon chart edition information and download link

     # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'
