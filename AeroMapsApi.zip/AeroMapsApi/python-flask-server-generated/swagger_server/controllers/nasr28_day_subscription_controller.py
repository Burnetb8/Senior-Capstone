import connexion
import six

from swagger_server import util


def get_nasr_edition(edition=None):  # noqa: E501
    """Get the National Flight Data Center NASR 28 day subscription file edition information

     # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'


def get_nasr_subscription(edition=None):  # noqa: E501
    """Get the National Flight Data Center NASR 28 day subscription file

     # noqa: E501

    :param edition: Requested product edition. If omitted, the default current edition is returned.
    :type edition: str

    :rtype: None
    """
    return 'do some magic!'
