import connexion
import six

from swagger_server import util


def get_ddof_edition():  # noqa: E501
    """Get Daily Digital Obstacle File edition information.

    The Daily Digital Obstacle File is released by the FAA on a daily basis. # noqa: E501


    :rtype: None
    """
    return 'do some magic!'


def get_ddof_release():  # noqa: E501
    """Get Daily Digital Obstacle File download link.

    The Daily Digital Obstacle File release is distributed as a zip file containing the latest obstacle information from the FAA database. # noqa: E501


    :rtype: None
    """
    return 'do some magic!'
