import connexion
import six

from swagger_server import util


def get_gom_edition(edition=None, geoname=None):  # noqa: E501
    """Get Gulf of Mexico IFR enroute chart edition date and edition number

    If a geographic area is not supplied, both central and west product edition information is returned. # noqa: E501

    :param edition: Requested product edition. If omitted, current edition is returned.
    :type edition: str
    :param geoname: Requested Gulf of Mexico geographic area. If omitted, both west and central are returned.
    :type geoname: str

    :rtype: None
    """
    return 'do some magic!'


def get_gom_release(edition=None, format=None, geoname=None):  # noqa: E501
    """Get Gulf of Mexico IFR enroute chart edition date, edition number, and product download URL

    The Gulf of Mexico IFR enroute chart is distributed as a zip file that contains multiple PDF charts. # noqa: E501

    :param edition: Requested product edition. If omitted, current edition is returned.
    :type edition: str
    :param format: Format of the requested chart. TIFF is georeferenced and PDF is not georeferenced. If omitted, the default format of PDF is returned.
    :type format: str
    :param geoname: Requested Gulf of Mexico geographic area. If omitted, both west and central links are returned.
    :type geoname: str

    :rtype: None
    """
    return 'do some magic!'
